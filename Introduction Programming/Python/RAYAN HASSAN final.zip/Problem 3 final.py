# -*- coding: utf-8 -*-
"""
Created on Sat May  2 09:15:55 2020

@author: RAYAN
"""

# “I, Rayan Hassan, promise to conduct the final and this problem on my own without external help.”

# Problem 3

n=int(input("Input shape length n:"))
file=open("out_triangle.txt","w")
if n>0:
    for i in range(1,n+1):
        S=""
        S+=" "*(n-i)
        S+="* "*(i)
#        print(S)
        file.write(S)
        file.write('\n')
else:
    n1=-n
    for i in range(1,n1+1):
        S=""
        S+=" "*(i-1)
        S+="* "*(n1-i+1)
#        print(S)
        file.write(S)
        file.write('\n')

file.close()


    