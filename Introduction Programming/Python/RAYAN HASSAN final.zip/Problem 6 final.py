# -*- coding: utf-8 -*-
"""
Created on Sat May  2 10:28:16 2020

@author: RAYAN
"""

# “I, Rayan Hassan, promise to conduct the final and this problem on my own without external help.”


# Problem 6

# Part a 
from math import sqrt
class Point:
    def __init__(self,x=0,y=0):
        assert (type(x)==int or type(x)==float) and (type(y)==int or type(y)==float),'Bad point data!'
        self.x=x
        self.y=y
    def __str__(self):
        return "("+str(self.x)+","+str(self.y)+")"
    
def distance(P,Q):
    assert type(P)==Point and type(Q)==Point,"Bad distance input!"
    summation=(P.x - Q.x)**2 + (P.y - Q.y)**2
    return sqrt(summation)

# Part b

class Circle:
    def __init__(self,center=Point(0,0),radius=1):
        assert type(center)==Point and (type(radius)==int or type(radius)==float),"Bad circle input!"
        self.center=center
        self.radius=radius
    def __str__(self):
        return "Circle"+"("+"Center= Point"+str(self.center) + ","+"Radius="+str(self.radius) + ")"
    def __add__(self,other):
        return Circle((self.center + other.center),(self.radius + other.radius))
    def contains(self,pt):
        assert type(pt)==Point,"Bad contain Input!"
        if distance(self.center,pt)<=self.radius:
            return True
        else:
            return False

# Part c

P1= Point(3.5,6)
P2=Point(2,4)
print("Point",P1,"Point",P2)
print("Distance between them is:",distance(P1,P2))
C1=Circle(Point(2,4),2.3)
print("C1:",C1)
print("Checking Contains for points Point(1.5,3) and Point(10.5,3)")
print(C1.contains(Point(1.5,3)))
print(C1.contains(Point(10.5,3)))
C2=Circle(Point(3.5,6),6.2)
print("C2:",C2)
print("Adding the two circles, C1+C2, we get:")
#print(C1+C2)

        
        
    
