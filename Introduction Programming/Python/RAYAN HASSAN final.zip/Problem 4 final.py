# -*- coding: utf-8 -*-
"""
Created on Sat May  2 09:36:05 2020

@author: RAYAN
"""

# “I, Rayan Hassan, promise to conduct the final and this problem on my own without external help.”


# Problem 4

# Part a 

sequence=str(input("Enter integers seperated by spaces:"))
L=sequence.split()
for w in range(len(L)):
    L[w]=int(L[w])

n = len(L)
List=[]  # List in which I will store all the lists of sequenced positive numbers
negative_numbers=0
max_length=0
for i in range(n):
    subList=[]
    if L[i]>=0:
        
        subList.append(L[i])
        length=1
        for j in range(i,n):
            
            if L[j]>=0:
                subList.append(L[j])
                length+=1
            else:
                negative_numbers+=1
        if length>max_length:
            max_length=length
        List.append(subList)
    else:
        negative_numbers+=1
print(List)        
if negative_numbers!=0:
    print("Negative numbers found")
    for k in range(len(List)):
        if len(List[k])>=len(List[0]):
            List[0]=List[k]
    print("Max-Count",len(List[0]))
    print("A max-count subsequence is:",List[0])
else:
    print("No negative numbers, the max-count is the whole list:")
    print(sequence)