# -*- coding: utf-8 -*-
"""
Created on Sat May  2 11:15:48 2020

@author: RAYAN
"""

# “I, Rayan Hassan, promise to conduct the final and this problem on my own without external help.”

# Part a 

def my_pal_Vector(V):
    def vector(V,a,b):

        if a>=b:
            return True   # array with one or no element
        elif V[a]==V[b]:
            return vector(V,a+1,b-1)
        else:
            return False
    boolean=vector(V,0,len(V)-1)
    return boolean

print("Vectors")
V=[1,2,3,2,1]
print(V,my_pal_Vector(V))
V=[1,2,3,3,2,1]
print(V,my_pal_Vector(V))
V=[1,2,3,5,1]
print(V,my_pal_Vector(V))
V=[1,2,3,4,2,1]
print(V,my_pal_Vector(V))

# Part b 

def my_pal_Matrix_R(A):
    if len(A)==0:    # if no rows/elements in matrix
        return True
    elif my_pal_Vector(A[0]):    # A[0] is the first row of the martrix, in our recursive call
                                 # we remove it after we check if it is palindrome
        return my_pal_Matrix_R(A.remove(A[0]))
    else:
        return False

    
#print("Matrices")
#A=[[1,2,1],[2,3,2],[1,2,1]]
#print(A,my_pal_Matrix_R(A))
#A=[[1,2,3,2,1],[2,3,4,3,2],[3,4,5,4,3],[2,3,4,3,2],[1,2,3,2,1]]
#print(A,my_pal_Matrix_R(A))
#A=[[1,2,1],[2,3,4],[1,1,1]]
#print(A,my_pal_Matrix_R(A))
#A=[[1,2,3,2,1],[2,3,44,3,2],[3,4,5,4,3],[2,3,4,3,2],[1,2,3,2,1]]
#print(A,my_pal_Matrix_R(A))

    
    