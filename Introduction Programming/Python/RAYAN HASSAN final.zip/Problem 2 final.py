# -*- coding: utf-8 -*-
"""
Created on Sat May  2 09:02:02 2020

@author: RAYAN
"""

# “I, Rayan Hassan, promise to conduct the final and this problem on my own without external help.” 

# Problem 2 

# Part a 
def perfect(n):
    if n<1:
        return False
    else:
        i=1
        summation=0
        while i<=n:
            if n%i==0: # so if n divisible by i 
                summation+=i    # add all the divisors i
            i+=1
        if summation==n:   # check if summation of divisors is equal to n, then it's perfect
            return True
        else:
            return False
        
# Part b
#n=4
#while n>0:
#    x=perfect(n)
#    if x==True:
#        print(x)
#        n-=1
    

    
                